const { Builder, By, Key, until } = require('selenium-webdriver');
const { logger } = require("../log");
(async function example() {
  let driver = await new Builder().forBrowser('firefox').build();
  driver.manage().window().maximize();
  try {
    //实现修改功能
    await driver.get('http://localhost:8081/#/app/manage');
    let delbutton = await driver.wait(until.elementLocated(By.css("a[href='#/app/manage/infoPerfect']")), 3000);
    await driver.wait(until.elementIsVisible(delbutton), 10000);
    await driver.wait(async function () {
      //这个是对于spinin
      try {
        await driver.findElement(By.className("dt-spin-spinning"));
        return false;
      } catch (e) {
        return true;
      }
    }, 3000);
    await delbutton.click();
    let systeminfo = await driver.wait(until.elementLocated(By.css(".dt-tabs-nav .dt-tabs-tab:last-child")), 3000);
    await systeminfo.click();
    //第一个下拉框下拉
    let selectarr = await driver.findElements(By.className('dt-select'));
    selectarr[0].click();
    let list = await driver.wait(until.elementLocated(By.className("dt-select-dropdown-menu-item")), 3000);
    await list.click();
    //第二个下拉框
    selectarr[1].click();
    await driver.wait(until.elementsLocated(By.css('ul[aria-activedescendant]')), 3000);
    let arr2 = await driver.findElements(By.className("dt-select-dropdown-menu-item"));
    arr2[5].click();
    //第三个下拉框
    selectarr[2].click();
    await driver.wait(async function () {
      arr2 = await driver.findElements(By.className("dt-select-dropdown-menu-item"));
      if (arr2.length > 29) {
        return true;
      } else {
        return false;
      }
    }, 3000);
    arr2[31].click();
    //填表单
    await driver.findElement(By.id('url')).sendKeys('http://www.baidu.com');
    await driver.findElement(By.id('statusUrl')).sendKeys('http://www.baidu.com');
    await driver.findElement(By.id('logoutUrl')).sendKeys('http://www.baidu.com');
   
    await driver.executeScript("document.querySelectorAll('input[type=file]')[1].style.display='block';document.querySelectorAll('input[type=file]')[0].style.display='block';");
    let filearr = await driver.findElements(By.css("input[type='file']"));
     filearr[0].sendKeys("\/home\/zd/Desktop\/Selection_033.png");
    await driver.executeScript("document.querySelectorAll('input[type=file]')[1].style.display='block';document.querySelectorAll('input[type=file]')[0].style.display='block';");
     filearr[1].sendKeys("\/home\/zd/Desktop\/Selection_033.png");
     


  } catch (e) {
    logger.warn(e);

    await driver.quit();
  }
})();


