const { Builder, By, Key, until } = require('selenium-webdriver');

const { logger } = require("../log");

(async function example() {
  let driver = await new Builder().forBrowser('firefox').build();
  try {
    //测试表单
    await driver.get('http://localhost:8081/#/index');
    let button = await driver.wait(until.elementLocated(By.css("a[href='#/app/manage']")), 3000);
    await button.click();
    let createbutton = await driver.wait(until.elementLocated(By.css("a[href='#/app/manage/create']")), 3000);
    await createbutton.click();
    let nameinput = await driver.wait(until.elementLocated(By.id('name')), 3000);
    await nameinput.sendKeys('test', Key.RETURN);
    let arr = await driver.findElements(By.className('dt-select'));
    arr[0].click();
    let list = await driver.wait(until.elementLocated(By.className("dt-select-dropdown-menu-item")), 3000);
    await list.click();
    arr[1].click();
    await driver.wait(until.elementLocated(By.css('ul[aria-activedescendant]')), 3000);
    let arr2 = await driver.findElements(By.className("dt-select-dropdown-menu-item"));
    arr2[8].click();
    await driver.findElement(By.id('ownerUser')).sendKeys('test', Key.RETURN);
    await driver.findElement(By.id('ownerPhone')).sendKeys('13166668888', Key.RETURN);
    await driver.findElement(By.id('ownerEmail'))   .sendKeys('13166668888@qq.com', Key.RETURN);
    await driver.findElement(By.id('developerInstitution')).sendKeys('test', Key.RETURN);
    await driver.findElement(By.id('developerUser')).sendKeys('test', Key.RETURN);
    await driver.findElement(By.id('developerPhone')).sendKeys('13166668888', Key.RETURN);
    await driver.findElement(By.id('developerEmail')).sendKeys('13166668888@qq.com', Key.RETURN);



  } catch (e) {
    logger.warn(e);
    await driver.quit();
  }
})();

